function showPopup() {
    var popup = document.getElementById("popup");
    popup.classList.remove("hidden");
  }
  
  function hidePopup() {
    var popup = document.getElementById("popup");
    popup.classList.add("hidden");
  }
  